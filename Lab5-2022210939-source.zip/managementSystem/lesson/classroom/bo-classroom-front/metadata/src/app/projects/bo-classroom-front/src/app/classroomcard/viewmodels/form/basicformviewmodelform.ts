
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgChildForm, NgChildFormArray, NgValidateForm } from '@farris/devkit';
import { DateConverter, MultiLangConverter } from '@farris/kendo-binding';

@Injectable()
@NgValidateForm({
    formGroupName: '教室',
    enableValidate: true
})

@Injectable()
export class BasicFormViewmodelForm extends Form {
    @NgFormControl({
        id: 'name_373f3582_2bfo',
        name: "{{name_373f3582_2bfo}}",
        binding: 'name',
        updateOn: 'blur',
        defaultI18nValue: '教室名称',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    name: FormControl;

    @NgFormControl({
        id: 'location_2508f93f_k8dh',
        name: "{{location_2508f93f_k8dh}}",
        binding: 'location',
        updateOn: 'blur',
        defaultI18nValue: '教室位置',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    location: FormControl;

    @NgFormControl({
        id: 'capacity_cadb42f5_xzx4',
        name: "{{capacity_cadb42f5_xzx4}}",
        binding: 'capacity',
        updateOn: 'blur',
        defaultI18nValue: '教室容量',
        validRules: [
            {
                type: 'required',
                constraints: [true],
            }
        ]
    })
    capacity: FormControl;

}