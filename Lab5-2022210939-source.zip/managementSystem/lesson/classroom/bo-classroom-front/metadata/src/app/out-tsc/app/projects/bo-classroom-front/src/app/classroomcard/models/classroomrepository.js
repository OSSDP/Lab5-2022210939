import * as tslib_1 from "tslib";
import { Injectable, Injector } from '@angular/core';
import { NgRepository } from '@farris/devkit';
import { BefRepository } from '@farris/bef';
import { ClassroomEntity } from './entities/classroomentity';
import { ClassroomProxy } from './classroomproxy';
var ClassroomRepository = /** @class */ (function (_super) {
    tslib_1.__extends(ClassroomRepository, _super);
    function ClassroomRepository(injector) {
        var _this = _super.call(this, injector) || this;
        _this.name = 'ClassroomRepository';
        _this.paginationInfo = {};
        _this.proxy = injector.get(ClassroomProxy, null);
        return _this;
    }
    ClassroomRepository = tslib_1.__decorate([
        Injectable(),
        NgRepository({
            apiUrl: 'api/managementsystem/lesson/v1.0/classroomcard_frm',
            entityType: ClassroomEntity
        }),
        tslib_1.__metadata("design:paramtypes", [Injector])
    ], ClassroomRepository);
    return ClassroomRepository;
}(BefRepository));
export { ClassroomRepository };
