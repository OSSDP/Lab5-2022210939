import * as tslib_1 from "tslib";
import { Injectable } from "@angular/core";
import { Declaration } from "@farris/devkit";
var EventDeclaration = /** @class */ (function (_super) {
    tslib_1.__extends(EventDeclaration, _super);
    function EventDeclaration() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    EventDeclaration = tslib_1.__decorate([
        Injectable()
    ], EventDeclaration);
    return EventDeclaration;
}(Declaration));
export { EventDeclaration };
