import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var ClassroomEntity = /** @class */ (function (_super) {
    tslib_1.__extends(ClassroomEntity, _super);
    function ClassroomEntity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ID',
            dataField: 'id',
            primary: true,
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ID',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], ClassroomEntity.prototype, "id", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Version',
            dataField: 'version',
            originalDataFieldType: 'DateTime',
            initValue: '0001-01-01T00:00:00',
            path: 'Version',
            enableTimeZone: true,
        }),
        tslib_1.__metadata("design:type", String)
    ], ClassroomEntity.prototype, "version", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'name',
            dataField: 'name',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'name',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], ClassroomEntity.prototype, "name", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'location',
            dataField: 'location',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'location',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], ClassroomEntity.prototype, "location", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'capacity',
            dataField: 'capacity',
            originalDataFieldType: 'Number',
            initValue: 0,
            path: 'capacity',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                }
            ]
        }),
        tslib_1.__metadata("design:type", Object)
    ], ClassroomEntity.prototype, "capacity", void 0);
    ClassroomEntity = tslib_1.__decorate([
        NgEntity({
            originalCode: "classroom",
            nodeCode: "classrooms",
            allowEmpty: true
        })
    ], ClassroomEntity);
    return ClassroomEntity;
}(Entity));
export { ClassroomEntity };
