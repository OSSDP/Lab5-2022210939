
import { Injectable, Injector } from '@angular/core';
import { NgRepository } from '@farris/devkit';
import { BefRepository, NgVariable } from '@farris/bef';
import { ClassroomEntity } from './entities/classroomentity';

import { ClassroomProxy } from './classroomproxy';

@Injectable()
@NgRepository({
    apiUrl: 'api/managementsystem/lesson/v1.0/classroommanagement_frm',
    entityType: ClassroomEntity
})
export class ClassroomRepository extends BefRepository<ClassroomEntity> {
    public name = 'ClassroomRepository';

    public proxy: ClassroomProxy;
    public paginationInfo = {
        ClassroomEntity: {
            pageSize: 20,
        }
    };
    constructor(injector: Injector) {
        super(injector);
        this.proxy = injector.get(ClassroomProxy, null);
    }
}