import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
var DataGridComponentViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(DataGridComponentViewmodelForm, _super);
    function DataGridComponentViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'name',
            name: "{{name_e7209856_1o8g}}",
            binding: 'name',
            updateOn: 'blur',
            defaultI18nValue: '课程名',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "name", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'exam_type',
            name: "{{exam_type_26e383a2_699c}}",
            binding: 'exam_type',
            updateOn: 'change',
            defaultI18nValue: '考试类型',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "exam_type", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'course_type',
            name: "{{course_type_4b0b2087_iweh}}",
            binding: 'course_type',
            updateOn: 'change',
            defaultI18nValue: '课程类型',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "course_type", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'credit',
            name: "{{credit_317ece46_erkw}}",
            binding: 'credit',
            updateOn: 'blur',
            defaultI18nValue: '学分',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "credit", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'course_number',
            name: "{{course_number_17e3d6a4_arhz}}",
            binding: 'course_number',
            updateOn: 'blur',
            defaultI18nValue: '课程代码',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "course_number", void 0);
    DataGridComponentViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '课程管理',
            enableValidate: false
        }),
        Injectable()
    ], DataGridComponentViewmodelForm);
    return DataGridComponentViewmodelForm;
}(Form));
export { DataGridComponentViewmodelForm };
