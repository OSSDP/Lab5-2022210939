
import { Entity, NgField, NgObject, EntityList, NgList, NgDynamic, DynamicEntity, NgEntity } from '@farris/devkit';

@NgEntity({
    originalCode: "course",
    nodeCode: "courses",
    allowEmpty: true
})
export class CourseEntity extends Entity {

    @NgField({
        originalDataField: 'ID',
        dataField: 'id',
        primary: true,
        originalDataFieldType: 'String',
        initValue: '',
        path: 'ID',

        validRules: [
            {
                type: 'required',
                constraints: [true],
            },
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    id: string;

    @NgField({
        originalDataField: 'Version',
        dataField: 'version',
        originalDataFieldType: 'DateTime',
        initValue: '0001-01-01T00:00:00',
        path: 'Version',
        enableTimeZone: true,
    })
    version: string;

    @NgField({
        originalDataField: 'name',
        dataField: 'name',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'name',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    name: string;

    @NgField({
        originalDataField: 'exam_type',
        dataField: 'exam_type',
        originalDataFieldType: 'Enum',
        defaultValue: '',
        initValue: '0',
        path: 'exam_type',
    })
    exam_type: any;

    @NgField({
        originalDataField: 'course_type',
        dataField: 'course_type',
        originalDataFieldType: 'Enum',
        defaultValue: '',
        initValue: '0',
        path: 'course_type',
    })
    course_type: any;

    @NgField({
        originalDataField: 'credit',
        dataField: 'credit',
        originalDataFieldType: 'Number',
        initValue: 0,
        path: 'credit',

        validRules: [
            {
                type: 'required',
                constraints: [true],
            }
        ]
    })
    credit: any;

    @NgField({
        originalDataField: 'course_number',
        dataField: 'course_number',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'course_number',

        validRules: [
            {
                type: 'required',
                constraints: [true],
            },
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    course_number: string;

}