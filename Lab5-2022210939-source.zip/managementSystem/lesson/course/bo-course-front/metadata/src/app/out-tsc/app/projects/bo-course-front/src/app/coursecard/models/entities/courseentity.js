import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var CourseEntity = /** @class */ (function (_super) {
    tslib_1.__extends(CourseEntity, _super);
    function CourseEntity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ID',
            dataField: 'id',
            primary: true,
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ID',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], CourseEntity.prototype, "id", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Version',
            dataField: 'version',
            originalDataFieldType: 'DateTime',
            initValue: '0001-01-01T00:00:00',
            path: 'Version',
            enableTimeZone: true,
        }),
        tslib_1.__metadata("design:type", String)
    ], CourseEntity.prototype, "version", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'name',
            dataField: 'name',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'name',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], CourseEntity.prototype, "name", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'exam_type',
            dataField: 'exam_type',
            originalDataFieldType: 'Enum',
            defaultValue: '',
            initValue: '0',
            path: 'exam_type',
        }),
        tslib_1.__metadata("design:type", Object)
    ], CourseEntity.prototype, "exam_type", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'course_type',
            dataField: 'course_type',
            originalDataFieldType: 'Enum',
            defaultValue: '',
            initValue: '0',
            path: 'course_type',
        }),
        tslib_1.__metadata("design:type", Object)
    ], CourseEntity.prototype, "course_type", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'credit',
            dataField: 'credit',
            originalDataFieldType: 'Number',
            initValue: 0,
            path: 'credit',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                }
            ]
        }),
        tslib_1.__metadata("design:type", Object)
    ], CourseEntity.prototype, "credit", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'course_number',
            dataField: 'course_number',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'course_number',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], CourseEntity.prototype, "course_number", void 0);
    CourseEntity = tslib_1.__decorate([
        NgEntity({
            originalCode: "course",
            nodeCode: "courses"
        })
    ], CourseEntity);
    return CourseEntity;
}(Entity));
export { CourseEntity };
