
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgChildForm, NgChildFormArray, NgValidateForm } from '@farris/devkit';
import { DateConverter, MultiLangConverter } from '@farris/kendo-binding';

@Injectable()
@NgValidateForm({
    formGroupName: '课程管理',
    enableValidate: false
})

@Injectable()
export class DataGridComponentViewmodelForm extends Form {
    @NgFormControl({
        id: 'name',
        name: "{{name_e7209856_1o8g}}",
        binding: 'name',
        updateOn: 'blur',
        defaultI18nValue: '课程名',
    })
    name: FormControl;

    @NgFormControl({
        id: 'exam_type',
        name: "{{exam_type_26e383a2_699c}}",
        binding: 'exam_type',
        updateOn: 'change',
        defaultI18nValue: '考试类型',
    })
    exam_type: FormControl;

    @NgFormControl({
        id: 'course_type',
        name: "{{course_type_4b0b2087_iweh}}",
        binding: 'course_type',
        updateOn: 'change',
        defaultI18nValue: '课程类型',
    })
    course_type: FormControl;

    @NgFormControl({
        id: 'credit',
        name: "{{credit_317ece46_erkw}}",
        binding: 'credit',
        updateOn: 'blur',
        defaultI18nValue: '学分',
    })
    credit: FormControl;

    @NgFormControl({
        id: 'course_number',
        name: "{{course_number_17e3d6a4_arhz}}",
        binding: 'course_number',
        updateOn: 'blur',
        defaultI18nValue: '课程代码',
    })
    course_number: FormControl;

}