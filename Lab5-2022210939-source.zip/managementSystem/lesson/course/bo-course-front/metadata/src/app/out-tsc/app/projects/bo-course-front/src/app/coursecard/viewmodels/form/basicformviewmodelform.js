import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
var BasicFormViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(BasicFormViewmodelForm, _super);
    function BasicFormViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'name_17988d5d_c4ev',
            name: "{{name_17988d5d_c4ev}}",
            binding: 'name',
            updateOn: 'blur',
            defaultI18nValue: '课程名',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "name", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'exam_type_dbe8f379_km8s',
            name: "{{exam_type_dbe8f379_km8s}}",
            binding: 'exam_type',
            updateOn: 'change',
            defaultI18nValue: '考试类型',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "exam_type", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'course_type_39a2a4e8_yu87',
            name: "{{course_type_39a2a4e8_yu87}}",
            binding: 'course_type',
            updateOn: 'change',
            defaultI18nValue: '课程类型',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "course_type", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'credit_1fd793b0_4fsv',
            name: "{{credit_1fd793b0_4fsv}}",
            binding: 'credit',
            updateOn: 'blur',
            defaultI18nValue: '学分',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "credit", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'course_number_7adcc933_i3bh',
            name: "{{course_number_7adcc933_i3bh}}",
            binding: 'course_number',
            updateOn: 'blur',
            defaultI18nValue: '课程代码',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "course_number", void 0);
    BasicFormViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '课程管理',
            enableValidate: true
        }),
        Injectable()
    ], BasicFormViewmodelForm);
    return BasicFormViewmodelForm;
}(Form));
export { BasicFormViewmodelForm };
