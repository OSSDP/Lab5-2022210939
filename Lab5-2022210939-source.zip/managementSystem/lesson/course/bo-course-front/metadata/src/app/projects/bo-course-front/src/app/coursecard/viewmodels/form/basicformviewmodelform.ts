
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgChildForm, NgChildFormArray, NgValidateForm } from '@farris/devkit';
import { DateConverter, MultiLangConverter } from '@farris/kendo-binding';

@Injectable()
@NgValidateForm({
    formGroupName: '课程管理',
    enableValidate: true
})

@Injectable()
export class BasicFormViewmodelForm extends Form {
    @NgFormControl({
        id: 'name_17988d5d_c4ev',
        name: "{{name_17988d5d_c4ev}}",
        binding: 'name',
        updateOn: 'blur',
        defaultI18nValue: '课程名',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    name: FormControl;

    @NgFormControl({
        id: 'exam_type_dbe8f379_km8s',
        name: "{{exam_type_dbe8f379_km8s}}",
        binding: 'exam_type',
        updateOn: 'change',
        defaultI18nValue: '考试类型',
    })
    exam_type: FormControl;

    @NgFormControl({
        id: 'course_type_39a2a4e8_yu87',
        name: "{{course_type_39a2a4e8_yu87}}",
        binding: 'course_type',
        updateOn: 'change',
        defaultI18nValue: '课程类型',
    })
    course_type: FormControl;

    @NgFormControl({
        id: 'credit_1fd793b0_4fsv',
        name: "{{credit_1fd793b0_4fsv}}",
        binding: 'credit',
        updateOn: 'blur',
        defaultI18nValue: '学分',
        validRules: [
            {
                type: 'required',
                constraints: [true],
            }
        ]
    })
    credit: FormControl;

    @NgFormControl({
        id: 'course_number_7adcc933_i3bh',
        name: "{{course_number_7adcc933_i3bh}}",
        binding: 'course_number',
        updateOn: 'blur',
        defaultI18nValue: '课程代码',
        validRules: [
            {
                type: 'required',
                constraints: [true],
            },
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    course_number: FormControl;

}